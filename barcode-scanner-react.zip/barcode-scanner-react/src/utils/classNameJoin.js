export const classNameJoin = (...classNames) => {
  return [...classNames].join(' ');
};
